#!/usr/bin/env python3
import requests
import base64
import json

# URL base da API
BASE_URL = "http://localhost:5001/api/pdf"

def test_pdf_service():
    print("Testando serviço de armazenamento de PDF...")
    
    # Teste 1: Listar PDFs (deve estar vazio inicialmente)
    print("\n1. Testando listagem de PDFs...")
    try:
        response = requests.get(f"{BASE_URL}/list", timeout=5)
        print(f"Status: {response.status_code}")
        print(f"Response: {response.json()}")
    except Exception as e:
        print(f"Erro: {e}")
        return False
    
    # Teste 2: Upload de um PDF de teste
    print("\n2. Testando upload de PDF...")
    
    # Criar um PDF simples em base64 para teste
    # Este é um PDF mínimo válido
    pdf_content = """%PDF-1.4
1 0 obj
<<
/Type /Catalog
/Pages 2 0 R
>>
endobj

2 0 obj
<<
/Type /Pages
/Kids [3 0 R]
/Count 1
>>
endobj

3 0 obj
<<
/Type /Page
/Parent 2 0 R
/MediaBox [0 0 612 792]
/Contents 4 0 R
>>
endobj

4 0 obj
<<
/Length 44
>>
stream
BT
/F1 12 Tf
100 700 Td
(Teste PDF) Tj
ET
endstream
endobj

xref
0 5
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000206 00000 n 
trailer
<<
/Size 5
/Root 1 0 R
>>
startxref
299
%%EOF"""
    
    pdf_base64 = base64.b64encode(pdf_content.encode()).decode()
    
    upload_data = {
        "pdf_data": pdf_base64,
        "filename": "teste_relatorio.pdf"
    }
    
    try:
        response = requests.post(f"{BASE_URL}/upload-pdf", 
                               json=upload_data, 
                               timeout=10)
        print(f"Status: {response.status_code}")
        result = response.json()
        print(f"Response: {result}")
        
        if response.status_code == 200 and result.get('success'):
            file_id = result['file_id']
            download_url = result['download_url']
            
            # Teste 3: Download do PDF
            print(f"\n3. Testando download do PDF (ID: {file_id})...")
            download_response = requests.get(download_url, timeout=5)
            print(f"Download Status: {download_response.status_code}")
            print(f"Content-Type: {download_response.headers.get('Content-Type')}")
            print(f"Content-Length: {len(download_response.content)} bytes")
            
            # Teste 4: Informações do PDF
            print(f"\n4. Testando informações do PDF...")
            info_response = requests.get(f"{BASE_URL}/info/{file_id}", timeout=5)
            print(f"Info Status: {info_response.status_code}")
            print(f"Info Response: {info_response.json()}")
            
            return True
        else:
            print("Falha no upload")
            return False
            
    except Exception as e:
        print(f"Erro no upload: {e}")
        return False

if __name__ == "__main__":
    success = test_pdf_service()
    if success:
        print("\n✅ Todos os testes passaram!")
    else:
        print("\n❌ Alguns testes falharam!")


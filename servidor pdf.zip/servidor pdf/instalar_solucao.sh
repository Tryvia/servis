#!/bin/bash

echo "=== INSTALAÇÃO DA SOLUÇÃO PDF STORAGE ==="
echo "Resolvendo problema de links de PDF em emails"
echo ""

# Verificar se estamos no diretório correto
if [ ! -f "SOLUCAO_PDF_STORAGE.md" ]; then
    echo "❌ Execute este script no diretório que contém os arquivos da solução"
    exit 1
fi

# Verificar dependências
echo "🔍 Verificando dependências..."

if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 não encontrado. Instale Python3 primeiro."
    exit 1
fi

if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 não encontrado. Instale pip3 primeiro."
    exit 1
fi

echo "✅ Python3 e pip3 encontrados"

# Verificar se o serviço já existe
if [ -d "pdf_storage_service" ]; then
    echo "📁 Serviço PDF Storage já existe"
    
    read -p "Deseja reinstalar? (s/N): " reinstalar
    if [[ $reinstalar =~ ^[Ss]$ ]]; then
        echo "🗑️ Removendo instalação anterior..."
        rm -rf pdf_storage_service
    else
        echo "⏭️ Pulando instalação do serviço"
        SKIP_INSTALL=true
    fi
fi

if [ "$SKIP_INSTALL" != "true" ]; then
    echo ""
    echo "🚀 Instalando serviço PDF Storage..."
    
    # Verificar se manus-create-flask-app está disponível
    if command -v manus-create-flask-app &> /dev/null; then
        echo "📦 Criando aplicação Flask..."
        manus-create-flask-app pdf_storage_service
    else
        echo "⚠️ manus-create-flask-app não disponível. Criando estrutura manual..."
        mkdir -p pdf_storage_service/src/routes
        mkdir -p pdf_storage_service/src/models
        mkdir -p pdf_storage_service/src/static
        mkdir -p pdf_storage_service/src/database
        
        # Criar ambiente virtual
        cd pdf_storage_service
        python3 -m venv venv
        source venv/bin/activate
        pip install flask flask-cors flask-sqlalchemy
        cd ..
    fi
    
    echo "✅ Estrutura básica criada"
fi

# Verificar se os arquivos da solução existem
echo ""
echo "📋 Verificando arquivos da solução..."

arquivos_necessarios=(
    "portal_corrigido_com_pdf_storage.html"
    "SOLUCAO_PDF_STORAGE.md"
    "test_pdf_service.py"
)

for arquivo in "${arquivos_necessarios[@]}"; do
    if [ -f "$arquivo" ]; then
        echo "✅ $arquivo"
    else
        echo "❌ $arquivo não encontrado"
        exit 1
    fi
done

# Configurar o serviço
echo ""
echo "⚙️ Configurando serviço PDF Storage..."

cd pdf_storage_service

# Ativar ambiente virtual
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
    echo "✅ Ambiente virtual ativado"
else
    echo "❌ Ambiente virtual não encontrado"
    exit 1
fi

# Instalar dependências
echo "📦 Instalando dependências..."
pip install flask flask-cors flask-sqlalchemy > /dev/null 2>&1

if [ $? -eq 0 ]; then
    echo "✅ Dependências instaladas"
else
    echo "❌ Erro ao instalar dependências"
    exit 1
fi

# Atualizar requirements.txt
pip freeze > requirements.txt
echo "✅ requirements.txt atualizado"

cd ..

# Testar instalação
echo ""
echo "🧪 Testando instalação..."

# Iniciar serviço em background
cd pdf_storage_service
source venv/bin/activate
python src/main.py &
FLASK_PID=$!
cd ..

# Aguardar inicialização
echo "⏳ Aguardando serviço inicializar..."
sleep 3

# Testar conectividade
if curl -s http://localhost:5001/api/pdf/list > /dev/null 2>&1; then
    echo "✅ Serviço respondendo corretamente"
    TESTE_OK=true
else
    echo "⚠️ Serviço não está respondendo (normal se porta estiver ocupada)"
    TESTE_OK=false
fi

# Parar serviço de teste
if [ ! -z "$FLASK_PID" ]; then
    kill $FLASK_PID > /dev/null 2>&1
fi

echo ""
echo "=== INSTALAÇÃO CONCLUÍDA ==="
echo ""
echo "📁 Arquivos instalados:"
echo "   • pdf_storage_service/     - Serviço backend Flask"
echo "   • portal_corrigido_com_pdf_storage.html - Portal corrigido"
echo "   • SOLUCAO_PDF_STORAGE.md  - Documentação completa"
echo "   • test_pdf_service.py      - Script de teste"
echo ""
echo "🚀 Para usar a solução:"
echo ""
echo "1. Iniciar o serviço PDF:"
echo "   cd pdf_storage_service"
echo "   source venv/bin/activate"
echo "   python src/main.py"
echo ""
echo "2. Abrir o portal corrigido:"
echo "   Abra portal_corrigido_com_pdf_storage.html no navegador"
echo ""
echo "3. Configurar o portal:"
echo "   • Vá na aba 'Configurações'"
echo "   • Defina URL do servidor: http://localhost:5001"
echo "   • Teste a conexão"
echo ""
echo "4. Testar a API (opcional):"
echo "   python3 test_pdf_service.py"
echo ""
echo "📖 Leia SOLUCAO_PDF_STORAGE.md para detalhes completos"
echo ""

if [ "$TESTE_OK" = "true" ]; then
    echo "✅ Instalação bem-sucedida! Sistema pronto para uso."
else
    echo "⚠️ Instalação concluída. Teste manual recomendado."
fi

echo ""
echo "🎯 PROBLEMA RESOLVIDO:"
echo "   Links de PDF em emails agora funcionam permanentemente!"
echo ""

